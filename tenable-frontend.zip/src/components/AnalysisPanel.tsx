import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export interface TimelinePoint {
  date: string
  count: number
}

export interface AnalysisData {
  total_reviews: number
  average_rating: number | null
  sentiment: {
    positive: number
    neutral: number
    negative: number
    unclassified: number
  }
  timeline: TimelinePoint[]
  period?: string
}

export interface AnalysisPanelProps {
  data: AnalysisData
  online: boolean
  onStartParsing: () => void
  isParsing?: boolean
  className?: string
}

const LABEL = 'text-xs font-medium uppercase tracking-wider text-zinc-400'

function pct(part: number, whole: number): number {
  return whole > 0 ? Math.round((part / whole) * 100) : 0
}

function Metric({
  label,
  value,
  suffix,
  accent,
}: {
  label: string
  value: string
  suffix?: string
  accent?: boolean
}) {
  return (
    <div className="border border-zinc-800 p-8">
      <p className={LABEL}>{label}</p>
      <p
        className={cn(
          'mt-6 text-6xl font-medium leading-none tracking-tight tabular-nums',
          accent ? 'text-lime' : 'text-white',
        )}
      >
        {value}
        {suffix && <span className="ml-1 text-2xl text-zinc-400">{suffix}</span>}
      </p>
    </div>
  )
}

function Timeline({ points }: { points: TimelinePoint[] }) {
  const W = 800
  const H = 200
  const PAD = 12

  if (points.length === 0) {
    return (
      <div className="flex h-[200px] items-center justify-center border border-zinc-800 text-xs uppercase tracking-wider text-zinc-600">
        Нет данных за период
      </div>
    )
  }

  const max = Math.max(...points.map((p) => p.count), 1)
  const step = points.length > 1 ? (W - PAD * 2) / (points.length - 1) : 0
  const coords = points.map((p, i) => ({
    x: points.length > 1 ? PAD + i * step : W / 2,
    y: H - PAD - (p.count / max) * (H - PAD * 2),
    ...p,
  }))
  const path = coords.map((c, i) => `${i === 0 ? 'M' : 'L'}${c.x},${c.y}`).join(' ')

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="h-[200px] w-full"
      role="img"
      aria-label="Динамика количества отзывов"
      preserveAspectRatio="none"
    >
      {[0.25, 0.5, 0.75].map((t) => (
        <line
          key={t}
          x1={0}
          x2={W}
          y1={H * t}
          y2={H * t}
          className="stroke-zinc-900"
          strokeWidth={1}
          vectorEffect="non-scaling-stroke"
        />
      ))}
      <path
        d={path}
        fill="none"
        className="stroke-zinc-500"
        strokeWidth={1.5}
        vectorEffect="non-scaling-stroke"
      />
      {coords.length <= 60 &&
        coords.map((c) => (
          <rect key={c.date} x={c.x - 3} y={c.y - 3} width={6} height={6} className="fill-lime">
            <title>{`${c.date}: ${c.count}`}</title>
          </rect>
        ))}
    </svg>
  )
}

export function AnalysisPanel({
  data,
  online,
  onStartParsing,
  isParsing = false,
  className,
}: AnalysisPanelProps) {
  const { sentiment: s } = data
  const classified = s.positive + s.neutral + s.negative
  const posPct = pct(s.positive, classified)
  const neuPct = pct(s.neutral, classified)
  const negPct = classified > 0 ? Math.max(0, 100 - posPct - neuPct) : 0

  return (
    <section
      aria-labelledby="analysis-title"
      className={cn('border border-zinc-800 bg-zinc-950 p-8', className)}
    >
      <header className="flex flex-wrap items-center justify-between gap-6">
        <div>
          <h2 id="analysis-title" className={LABEL}>
            Аналитика{data.period ? ` · ${data.period}` : ''}
          </h2>
          <p className="mt-3 flex items-center gap-2 text-xs uppercase tracking-wider text-zinc-400">
            <span
              aria-hidden="true"
              className={cn('size-2', online ? 'bg-lime' : 'bg-zinc-700')}
            />
            {online ? 'Онлайн' : 'Офлайн'}
          </p>
        </div>
        <Button onClick={onStartParsing} disabled={isParsing}>
          {isParsing ? 'Сбор идёт…' : 'Запустить сбор'}
        </Button>
      </header>

      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <Metric label="Всего отзывов" value={data.total_reviews.toLocaleString('ru-RU')} />
        <Metric
          label="Средняя оценка"
          value={data.average_rating === null ? '—' : data.average_rating.toFixed(1)}
        />
        <Metric label="Позитивные" value={String(posPct)} suffix="%" accent />
      </div>

      <div className="mt-8 border border-zinc-800 p-8">
        <p className={LABEL}>Динамика отзывов</p>
        <div className="mt-6">
          <Timeline points={data.timeline} />
        </div>
      </div>

      <div className="mt-8 border border-zinc-800 p-8">
        <p className={LABEL}>Тональность</p>
        <div
          className="mt-6 flex h-3 w-full bg-zinc-900"
          role="img"
          aria-label={`Позитив ${posPct}%, нейтрально ${neuPct}%, негатив ${negPct}%`}
        >
          <div className="h-full bg-lime" style={{ width: `${posPct}%` }} />
          <div className="h-full bg-zinc-600" style={{ width: `${neuPct}%` }} />
          <div className="h-full bg-plum" style={{ width: `${negPct}%` }} />
        </div>
        <dl className="mt-6 grid grid-cols-2 gap-6 text-xs uppercase tracking-wider text-zinc-400 md:grid-cols-4">
          {(
            [
              ['Позитив', s.positive, 'bg-lime'],
              ['Нейтрально', s.neutral, 'bg-zinc-600'],
              ['Негатив', s.negative, 'bg-plum'],
              ['Не размечено', s.unclassified, 'bg-zinc-800'],
            ] as const
          ).map(([name, n, dot]) => (
            <div key={name} className="flex items-center gap-3">
              <span aria-hidden="true" className={cn('size-2 shrink-0', dot)} />
              <dt>{name}</dt>
              <dd className="ml-auto text-white tabular-nums">{n.toLocaleString('ru-RU')}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}
