import { Database } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export type Sentiment = 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE'
export type Platform = '2gis' | 'yandex' | 'google'

export interface ReviewItem {
  id: string
  platform: Platform
  author_name: string | null
  text: string
  rating: number | null
  published_at: string | null
  sentiment: Sentiment | null
  is_critical: boolean
}

export interface ReviewsTableProps {
  reviews: ReviewItem[]
  total: number
  onStartParsing?: () => void
  className?: string
}

const PLATFORM_LABEL: Record<Platform, string> = {
  '2gis': '2ГИС',
  yandex: 'Яндекс',
  google: 'Google',
}

const SENTIMENT_LABEL: Record<Sentiment, string> = {
  POSITIVE: 'Позитив',
  NEUTRAL: 'Нейтрально',
  NEGATIVE: 'Негатив',
}

const SENTIMENT_STYLE: Record<Sentiment, string> = {
  POSITIVE: 'border-lime bg-lime text-black',
  NEUTRAL: 'border-zinc-700 bg-transparent text-zinc-400',
  NEGATIVE: 'border-plum bg-plum text-white',
}

const BADGE =
  'inline-flex items-center rounded-sm border px-2 py-1 text-xs font-semibold uppercase leading-none tracking-wider'

function formatDate(iso: string | null): string {
  if (!iso) return '—'
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return '—'
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

export function ReviewsTable({ reviews, total, onStartParsing, className }: ReviewsTableProps) {
  return (
    <section
      aria-labelledby="reviews-title"
      className={cn('border border-zinc-800 bg-zinc-950', className)}
    >
      <header className="flex items-baseline justify-between border-b border-zinc-800 px-8 py-6">
        <h2
          id="reviews-title"
          className="text-xs font-medium uppercase tracking-wider text-zinc-400"
        >
          Отзывы
        </h2>
        <span className="text-xs uppercase tracking-wider text-zinc-400 tabular-nums">
          Всего: <span className="text-white">{total.toLocaleString('ru-RU')}</span>
        </span>
      </header>

      {reviews.length === 0 ? (
        <div className="flex flex-col items-center px-8 py-20 text-center">
          <Database className="mx-auto mb-4 h-12 w-12 text-zinc-700" strokeWidth={1.25} aria-hidden="true" />
          <p className="text-sm font-medium uppercase tracking-wider text-zinc-300">
            Отзывов пока нет
          </p>
          <p className="mt-2 max-w-sm text-sm text-zinc-500">
            Запустите сбор, чтобы загрузить отзывы с подключённых площадок.
          </p>
          {onStartParsing && (
            <Button className="mt-8" onClick={onStartParsing}>
              Запустить сбор
            </Button>
          )}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-left">
            <thead>
              <tr className="border-b border-zinc-800">
                {['Площадка', 'Автор', 'Отзыв', 'Оценка', 'Тональность', 'Дата'].map((h) => (
                  <th
                    key={h}
                    scope="col"
                    className="px-6 py-4 text-xs font-medium uppercase tracking-wider text-zinc-400"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {reviews.map((r) => (
                <tr key={r.id} className="align-top hover:bg-zinc-900/50">
                  <td className="px-6 py-5 text-xs uppercase tracking-wider text-zinc-400">
                    {PLATFORM_LABEL[r.platform]}
                  </td>
                  <td className="px-6 py-5 text-sm text-white">{r.author_name ?? 'Аноним'}</td>
                  <td className="max-w-md px-6 py-5 text-sm leading-relaxed text-zinc-300">
                    <p className="line-clamp-3">{r.text}</p>
                  </td>
                  <td className="px-6 py-5 text-sm tabular-nums text-white">
                    {r.rating ?? '—'}
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-wrap gap-2">
                      {r.sentiment ? (
                        <span className={cn(BADGE, SENTIMENT_STYLE[r.sentiment])}>
                          {SENTIMENT_LABEL[r.sentiment]}
                        </span>
                      ) : (
                        <span className={cn(BADGE, 'border-zinc-800 text-zinc-600')}>—</span>
                      )}
                      {r.is_critical && (
                        <span className={cn(BADGE, 'border-white bg-white text-black')}>
                          Критично
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-sm tabular-nums text-zinc-400">
                    {formatDate(r.published_at)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}
