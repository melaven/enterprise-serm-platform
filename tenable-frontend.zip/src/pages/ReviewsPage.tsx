import { useId, useRef, useState, type FormEvent } from 'react';

import { ReviewsTable, type ReviewItem } from '@/components/ReviewsTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { parserApi } from '@/lib/api/index.ts';
import type { Platform } from '@/lib/api/parser.ts';
import { useParsingJob } from '@/lib/useParsingJob.ts';

const PLATFORMS: ReadonlyArray<{ value: Platform; label: string }> = [
  { value: 'trustpilot', label: 'Trustpilot' },
  { value: 'yandex', label: 'Яндекс.Карты' },
  { value: '2gis', label: '2ГИС' },
  { value: 'google', label: 'Google' },
];

const LABEL = 'block text-xs font-medium uppercase tracking-wider text-zinc-400';
const SELECT =
  'h-11 w-full rounded-sm border border-zinc-800 bg-zinc-950 px-4 text-sm text-white focus-visible:border-lime focus-visible:outline-none disabled:opacity-40';

export interface ReviewsPageProps {
  reviews: ReviewItem[];
  total: number;
  /** Вызывается после успешного сбора: перезапросите список отзывов. */
  onJobFinished: () => void;
}

export function ReviewsPage({ reviews, total, onJobFinished }: ReviewsPageProps) {
  const uid = useId();
  const urlRef = useRef<HTMLInputElement>(null);
  const [platform, setPlatform] = useState<Platform>('trustpilot');
  const [url, setUrl] = useState('');
  const { isParsing, phase, start } = useParsingJob(parserApi, () => onJobFinished());

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    void start(platform, url.trim());
  }

  return (
    <div className="space-y-8">
      <form
        onSubmit={handleSubmit}
        className="grid gap-6 border border-zinc-800 bg-zinc-950 p-8 md:grid-cols-[14rem_1fr_auto] md:items-end"
      >
        <div className="space-y-2">
          <label htmlFor={`${uid}-platform`} className={LABEL}>
            Площадка
          </label>
          <select
            id={`${uid}-platform`}
            className={SELECT}
            value={platform}
            onChange={(e) => setPlatform(e.target.value as Platform)}
            disabled={isParsing}
          >
            {PLATFORMS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <label htmlFor={`${uid}-url`} className={LABEL}>
            Ссылка на страницу компании
          </label>
          <Input
            ref={urlRef}
            id={`${uid}-url`}
            type="url"
            required
            placeholder="https://"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            disabled={isParsing}
          />
        </div>
        <Button type="submit" disabled={isParsing}>
          {phase === 'starting' ? 'Запуск…' : phase === 'running' ? 'Сбор идёт…' : 'Запустить сбор'}
        </Button>
      </form>

      <ReviewsTable
        reviews={reviews}
        total={total}
        onStartParsing={() => urlRef.current?.focus()}
      />
    </div>
  );
}
